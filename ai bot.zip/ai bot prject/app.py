import os

import streamlit as st
from openai import OpenAI

from qa_bot import (
    build_context,
    extract_documents,
    retrieve,
)


st.set_page_config(
    page_title="AI Assistant",
    page_icon="🤖",
    layout="centered",
)

st.markdown(
    """
    <style>
    .block-container {max-width: 850px; padding-top: 2rem;}
    .stChatMessage {border-radius: 16px;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("🤖  AI Assistant")
st.caption("Upload company documents, then ask questions and get source-backed answers.")

with st.sidebar:
    st.header("Setup")
    uploaded_files = st.file_uploader(
        "Upload knowledge files",
        type=["pdf", "txt", "md"],
        accept_multiple_files=True,
        help="Text-based PDFs work best. Scanned PDFs need OCR.",
    )
    api_key = st.text_input(
        "OpenAI API key (optional)",
        value=os.getenv("OPENAI_API_KEY", ""),
        type="password",
        help="Without a key, the app returns the most relevant document excerpts.",
    )
    model = st.text_input(
        "Model",
        value=os.getenv("OPENAI_MODEL", "gpt-5.5"),
    )
    st.divider()
    st.markdown(
        "**Try asking:**\n\n"
        "- What are the working hours?\n"
        "- How many leave days are allowed?\n"
        "- Summarize the internship rules."
    )
    if st.button("Clear conversation", use_container_width=True):
        st.session_state.messages = []
        st.rerun()


@st.cache_data(show_spinner=False)
def load_documents(files: list[tuple[str, bytes]]) -> list[dict]:
    return extract_documents(files)


file_payloads = [(item.name, item.getvalue()) for item in uploaded_files]
documents = load_documents(file_payloads) if file_payloads else []

if "messages" not in st.session_state:
    st.session_state.messages = []

if documents:
    st.success(f"Ready — {len(documents)} searchable sections loaded.")
else:
    st.info(
        "Upload a PDF, TXT, or Markdown file to begin. "
        "You can use `sample_knowledge.txt` included with this project."
    )

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

question = st.chat_input("Ask a question about your documents…", disabled=not documents)

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    matches = retrieve(question, documents, limit=4)

    with st.chat_message("assistant"):
        if not matches:
            answer = "I could not find relevant information in the uploaded documents."
            st.markdown(answer)
        elif not api_key:
            answer = (
                "I found these relevant passages. Add an OpenAI API key in the sidebar "
                "for a natural-language answer.\n\n"
                + "\n\n".join(
                    f"**[{index}] {match['source']}**\n\n{match['text']}"
                    for index, match in enumerate(matches, start=1)
                )
            )
            st.markdown(answer)
        else:
            context = build_context(matches)
            instructions = (
                "You are a careful internship document assistant. "
                "Answer only from the supplied document context. "
                "If the context does not contain the answer, say that clearly. "
                "Cite supporting passages using [1], [2], and so on. "
                "Keep the answer concise and practical."
            )
            conversation = "\n".join(
                f"{item['role'].upper()}: {item['content']}"
                for item in st.session_state.messages[-6:]
            )
            prompt = (
                f"DOCUMENT CONTEXT:\n{context}\n\n"
                f"RECENT CONVERSATION:\n{conversation}\n\n"
                f"QUESTION: {question}"
            )

            try:
                with st.spinner("Reading the documents…"):
                    response = OpenAI(api_key=api_key).responses.create(
                        model=model,
                        instructions=instructions,
                        input=prompt,
                    )
                answer = response.output_text
                st.markdown(answer)
                with st.expander("Sources used"):
                    for index, match in enumerate(matches, start=1):
                        st.markdown(f"**[{index}] {match['source']}**")
                        st.caption(match["text"])
            except Exception as error:
                answer = (
                    "I could not contact the AI service. Check your API key, model name, "
                    f"and internet connection.\n\nDetails: `{error}`"
                )
                st.error(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})
