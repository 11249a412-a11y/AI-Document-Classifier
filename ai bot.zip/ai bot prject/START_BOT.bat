@echo off
cd /d "%~dp0"
echo Starting your AI bot...
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://localhost:8501'"
".venv\Scripts\python.exe" -m streamlit run app.py --server.headless=true --browser.gatherUsageStats=false --server.port=8501
echo.
echo The bot stopped. Press any key to close this window.
pause >nul
