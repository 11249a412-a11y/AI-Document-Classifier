# Internship AI Assistant

A document-question-answering chatbot built for an internship demonstration. Users
upload PDF, TXT, or Markdown files and ask questions about their content. The app
retrieves relevant passages, generates a concise answer, and shows its sources.

## Features

- Multiple document uploads
- PDF, TXT, and Markdown support
- Source-backed answers
- Conversation history
- Useful fallback mode without an API key
- Configurable OpenAI model

## Run the project

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment:

   **Windows PowerShell**

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install the packages:

   ```powershell
   pip install -r requirements.txt
   ```

5. Start the app:

   ```powershell
   streamlit run app.py
   ```

6. Upload `sample_knowledge.txt`, or upload your own documents.
7. Add an OpenAI API key in the sidebar for generated answers. Without a key, the
   app still displays the most relevant passages.

Create an API key in the
[OpenAI API dashboard](https://platform.openai.com/api-keys). Do not commit or
share your key.

## Run the tests

```powershell
pip install pytest
pytest
```

## How it works

1. Text is extracted from each uploaded document.
2. Long text is divided into overlapping sections.
3. The question is matched against those sections.
4. The most relevant sections are sent to the OpenAI Responses API.
5. The bot answers only from that context and cites the matching sources.

## Ideas for your internship presentation

- Replace the title and sample handbook with your organization's use case.
- Demonstrate a correct answer and an out-of-scope question.
- Explain that retrieval reduces unsupported answers.
- Mention future improvements such as login, OCR for scanned PDFs, feedback
  buttons, a database, and multilingual support.
