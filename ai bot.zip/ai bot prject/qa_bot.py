import io
import math
import re
from collections import Counter

from pypdf import PdfReader


WORD_PATTERN = re.compile(r"[a-zA-Z0-9']+")
STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "has", "have", "how", "i", "in", "is", "it", "of", "on", "or",
    "that", "the", "this", "to", "was", "what", "when", "where", "who",
    "will", "with",
}


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def chunk_text(text: str, source: str, chunk_size: int = 900, overlap: int = 150) -> list[dict]:
    text = clean_text(text)
    if not text:
        return []

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            boundary = text.rfind(" ", start, end)
            if boundary > start + chunk_size // 2:
                end = boundary
        chunks.append({"source": source, "text": text[start:end].strip()})
        if end == len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def extract_documents(files: list[tuple[str, bytes]]) -> list[dict]:
    documents = []
    for filename, content in files:
        if filename.lower().endswith(".pdf"):
            reader = PdfReader(io.BytesIO(content))
            for page_number, page in enumerate(reader.pages, start=1):
                page_text = page.extract_text() or ""
                documents.extend(
                    chunk_text(page_text, f"{filename}, page {page_number}")
                )
        else:
            text = content.decode("utf-8", errors="ignore")
            documents.extend(chunk_text(text, filename))
    return documents


def tokenize(text: str) -> list[str]:
    return [
        token
        for token in WORD_PATTERN.findall(text.lower())
        if token not in STOP_WORDS and len(token) > 1
    ]


def relevance_score(question: str, passage: str) -> float:
    query_tokens = tokenize(question)
    passage_counts = Counter(tokenize(passage))
    if not query_tokens or not passage_counts:
        return 0.0

    score = sum(
        1.0 + math.log(passage_counts[token])
        for token in set(query_tokens)
        if token in passage_counts
    )
    phrase_bonus = 2.0 if clean_text(question).lower() in passage.lower() else 0.0
    return score + phrase_bonus


def retrieve(question: str, documents: list[dict], limit: int = 4) -> list[dict]:
    scored = [
        (relevance_score(question, document["text"]), document)
        for document in documents
    ]
    scored.sort(key=lambda item: item[0], reverse=True)
    return [document for score, document in scored[:limit] if score > 0]


def build_context(matches: list[dict]) -> str:
    return "\n\n".join(
        f"[{index}] SOURCE: {match['source']}\n{match['text']}"
        for index, match in enumerate(matches, start=1)
    )
