import re

import streamlit as st

from website_converter import build_android_project


st.set_page_config(
    page_title="Website to Android",
    page_icon="📱",
    layout="centered",
)

st.title("📱 Website ZIP → Android App")
st.write(
    "Upload a website containing `index.html`. "
    "You will receive an Android Studio project containing your website."
)

website_zip = st.file_uploader("Upload your website ZIP", type=["zip"])
app_name = st.text_input("App name", value="My Website App", max_chars=50)
suggested_id = re.sub(r"[^a-z0-9]+", "", app_name.lower()) or "websiteapp"
package_name = st.text_input(
    "Package name",
    value=f"com.example.{suggested_id}",
    help="A unique lowercase identifier, for example com.yourname.myapp",
)

if st.button(
    "Convert website",
    type="primary",
    use_container_width=True,
    disabled=website_zip is None,
):
    try:
        project_zip = build_android_project(
            website_zip.getvalue(),
            app_name,
            package_name,
        )
        st.success("Your Android project is ready.")
        st.download_button(
            "Download Android project",
            data=project_zip,
            file_name=f"{suggested_id}-android.zip",
            mime="application/zip",
            use_container_width=True,
        )
        st.info(
            "To create the APK: extract the downloaded ZIP, open it in Android "
            "Studio, and choose Build → Build APK(s)."
        )
    except ValueError as error:
        st.error(str(error))

with st.expander("Required ZIP structure"):
    st.code(
        """my-website.zip
├── index.html
├── style.css
├── script.js
└── images/
    └── logo.png"""
    )

st.warning(
    "Only convert websites you own or have permission to use. "
    "Server-side code such as PHP, Python, or databases cannot run inside this app."
)
