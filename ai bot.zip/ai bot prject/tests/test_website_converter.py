import io
import zipfile

import pytest

from website_converter import build_android_project, extract_website


def make_zip(files: dict[str, bytes | str]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        for path, content in files.items():
            archive.writestr(path, content)
    return output.getvalue()


def test_extracts_website_from_top_level_folder():
    source = make_zip(
        {
            "website/index.html": "<h1>Hello</h1>",
            "website/css/style.css": "h1 { color: blue; }",
        }
    )
    files = dict(extract_website(source))
    assert files[next(path for path in files if str(path) == "index.html")] == b"<h1>Hello</h1>"


def test_rejects_zip_without_index():
    with pytest.raises(ValueError, match="index.html"):
        extract_website(make_zip({"about.html": "About"}))


def test_builds_android_project_with_website_assets():
    result = build_android_project(
        make_zip({"index.html": "<h1>App</h1>", "app.js": "console.log('ok')"}),
        "Demo App",
        "com.example.demo",
    )
    with zipfile.ZipFile(io.BytesIO(result)) as archive:
        names = archive.namelist()
        assert "app/src/main/assets/www/index.html" in names
        assert "app/src/main/assets/www/app.js" in names
        manifest = archive.read("app/src/main/AndroidManifest.xml").decode()
        assert 'android:label="Demo App"' in manifest
