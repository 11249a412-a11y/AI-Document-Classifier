from qa_bot import build_context, chunk_text, retrieve


def test_chunk_text_keeps_source():
    chunks = chunk_text("word " * 300, "handbook.txt", chunk_size=100, overlap=10)
    assert len(chunks) > 1
    assert all(chunk["source"] == "handbook.txt" for chunk in chunks)


def test_retrieve_finds_relevant_passage():
    documents = [
        {"source": "leave.txt", "text": "Interns receive two personal leave days."},
        {"source": "hours.txt", "text": "Working hours are 9:30 AM to 5:30 PM."},
    ]
    result = retrieve("How many leave days do interns get?", documents, limit=1)
    assert result[0]["source"] == "leave.txt"


def test_build_context_numbers_sources():
    context = build_context(
        [{"source": "guide.pdf, page 2", "text": "Keep data confidential."}]
    )
    assert "[1] SOURCE: guide.pdf, page 2" in context
